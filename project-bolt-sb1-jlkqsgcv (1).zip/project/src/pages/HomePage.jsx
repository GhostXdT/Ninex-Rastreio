import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaBox, FaSearch } from 'react-icons/fa';

function HomePage() {
  const [codigo, setCodigo] = useState('');
  const [erro, setErro] = useState('');
  const navigate = useNavigate();

  const validarCodigo = (codigo) => {
    // Correios: 13 caracteres, formato AA123456789BR
    const correiosRegex = /^[A-Z]{2}\d{9}[A-Z]{2}$/;
    
    // Jadlog: 14 dígitos numéricos
    const jadlogRegex = /^\d{14}$/;

    if (correiosRegex.test(codigo)) {
      return 'correios';
    } else if (jadlogRegex.test(codigo)) {
      return 'jadlog';
    }
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const transportadora = validarCodigo(codigo);

    if (!codigo) {
      setErro('Por favor, insira um código de rastreamento.');
      return;
    }

    if (!transportadora) {
      setErro('Código de rastreamento inválido. Verifique o formato.');
      return;
    }

    setErro('');
    navigate(`/${transportadora}/${codigo}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <FaBox className="text-6xl text-blue-600 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-800 mb-4">
              Ninex Rastreios
            </h1>
            <p className="text-gray-600">
              Rastreie suas encomendas dos Correios e Jadlog em um só lugar
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label 
                  htmlFor="codigo" 
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Código de Rastreamento
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="codigo"
                    value={codigo}
                    onChange={(e) => setCodigo(e.target.value.toUpperCase())}
                    className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Digite o código de rastreamento"
                  />
                  <FaSearch className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
              </div>

              {erro && (
                <div className="text-red-500 text-sm mt-2">
                  {erro}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-200 flex items-center justify-center space-x-2"
              >
                <span>Rastrear Encomenda</span>
              </button>
            </form>

            <div className="mt-8 border-t pt-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-4">
                Exemplos de Códigos:
              </h2>
              <div className="space-y-3 text-sm text-gray-600">
                <p>
                  <span className="font-medium">Correios:</span> AA933261003BR
                </p>
                <p>
                  <span className="font-medium">Jadlog:</span> 18176601079447
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;