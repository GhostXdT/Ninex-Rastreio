import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { FaArrowLeft, FaTruck } from 'react-icons/fa';

function JadlogTracking() {
  const { codigo } = useParams();

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-red-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Link
            to="/"
            className="inline-flex items-center text-red-600 hover:text-red-700 mb-6"
          >
            <FaArrowLeft className="mr-2" />
            Voltar
          </Link>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex items-center justify-center mb-6">
              <FaTruck className="text-4xl text-red-600 mr-4" />
              <h1 className="text-2xl font-bold text-gray-800">
                Rastreamento Jadlog
              </h1>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-2">
                Código de Rastreamento:
              </h2>
              <p className="text-red-600 font-mono text-xl">{codigo}</p>
            </div>

            <div className="bg-red-50 rounded-lg p-6">
              <p className="text-center text-gray-600">
                Para visualizar o rastreamento completo, acesse o site da Jadlog:
              </p>
              <a
                href={`https://www.jadlog.com.br/siteInstitucional/tracking.jad?cte=${codigo}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full mt-4 bg-red-600 text-white py-3 px-6 rounded-lg hover:bg-red-700 transition duration-200 text-center"
              >
                Acompanhar no site da Jadlog
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default JadlogTracking;