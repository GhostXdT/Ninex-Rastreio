import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { FaArrowLeft, FaTruck } from 'react-icons/fa';

function CorreiosTracking() {
  const { codigo } = useParams();

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-yellow-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Link
            to="/"
            className="inline-flex items-center text-yellow-600 hover:text-yellow-700 mb-6"
          >
            <FaArrowLeft className="mr-2" />
            Voltar
          </Link>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex items-center justify-center mb-6">
              <FaTruck className="text-4xl text-yellow-600 mr-4" />
              <h1 className="text-2xl font-bold text-gray-800">
                Rastreamento Correios
              </h1>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-2">
                Código de Rastreamento:
              </h2>
              <p className="text-yellow-600 font-mono text-xl">{codigo}</p>
            </div>

            <div className="bg-yellow-50 rounded-lg p-6">
              <p className="text-center text-gray-600">
                Para visualizar o rastreamento completo, acesse o site dos Correios:
              </p>
              <a
                href={`https://rastreamento.correios.com.br/app/index.php?codigo=${codigo}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full mt-4 bg-yellow-600 text-white py-3 px-6 rounded-lg hover:bg-yellow-700 transition duration-200 text-center"
              >
                Acompanhar no site dos Correios
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CorreiosTracking;