import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CorreiosTracking from './pages/CorreiosTracking';
import JadlogTracking from './pages/JadlogTracking';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/correios/:codigo" element={<CorreiosTracking />} />
        <Route path="/jadlog/:codigo" element={<JadlogTracking />} />
      </Routes>
    </Router>
  );
}

export default App;